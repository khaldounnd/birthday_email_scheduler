<?php

$service_url     = 'http://localhost:8000/api/sendEmail';
$curl           = curl_init($service_url);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($curl, CURLOPT_HTTPHEADER, array(
    'Content-Type: application/x-www-form-urlencoded',
));

$curl_response   = curl_exec($curl);
print_r($curl_response);
  

?>